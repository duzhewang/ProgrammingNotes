###################################################
### chunk number 1: runSweave eval=FALSE
###################################################
## Sweave("foo.Rnw")


###################################################
### chunk number 2: sleepExample eval=FALSE
###################################################
## set.seed(1)
## x <- local({
##     Sys.sleep(10)
##     rnorm(100)
## })
## results <- mean(x)


###################################################
### chunk number 3: useCacheSweave eval=FALSE
###################################################
## library(cacheSweave)
## Sweave("foo.Rnw", driver = cacheSweaveDriver)


###################################################
### chunk number 4: simpleExpr eval=FALSE
###################################################
## x <- 1:100


